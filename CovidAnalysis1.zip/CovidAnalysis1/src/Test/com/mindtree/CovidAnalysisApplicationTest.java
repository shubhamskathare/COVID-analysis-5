package com.mindtree;

import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.mindtree.dao.CovidDataDaoImpl;
import com.mindtree.exception.InvalidStateCodeException;
import com.mindtree.exception.StateNotFound;
import com.mindtree.model.CovidData;

class CovidAnalysisApplicationTest {

	CovidDataDaoImpl dao;

	public CovidAnalysisApplicationTest() {
		dao = new CovidDataDaoImpl();
	}

	@Test
	void testFuncionalityNameValidData() throws SQLException, InvalidStateCodeException, StateNotFound {
		String state = "TN"; // valid data
		List<CovidData> data = new ArrayList<>();
		data = dao.getListOfState();
		boolean res = false;
		for (CovidData x : data) {
			if (x.getState().contains(state)) {
				res = true;
				break;
			} else {
				res = false;

			}
		}
		assertTrue(res);
		
		if (res == false) {
			// throw new StateNotFound("Checked state is not found");
			throw new InvalidStateCodeException("Invalid StateCode we cant find ");
		}
		

	}

	@Test
	void testFunctionalityNameNoRecords() throws SQLException, InvalidStateCodeException {
		String State = "TNS"; // invalid data(state)

		List<CovidData> data2 = new ArrayList<>();
		data2 = dao.getListofDistrictByState(State);

		boolean result = data2.isEmpty();

		if (result) {
			throw new InvalidStateCodeException("Invalid StateCode we cant find districts ");
		}
		// assertFalse(result);

	}

}
