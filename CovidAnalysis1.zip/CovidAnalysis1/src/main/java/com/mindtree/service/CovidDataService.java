package com.mindtree.service;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.mindtree.dao.CovidDataDaoImpl;
import com.mindtree.exception.InvalidDateException;
import com.mindtree.exception.InvalidDateRangeException;
import com.mindtree.exception.InvalidStateCodeException;
import com.mindtree.exception.NoDataFoundException;
import com.mindtree.model.CovidData;

public class CovidDataService {

	private CovidDataDaoImpl dao;
	private String state_1;
	private String tested;
	private String confirmed1;

	public CovidDataService() {
		dao = new CovidDataDaoImpl();
	}


	public void getAllState() {
		// TODO Auto-generated method stub
		Collection<CovidData> states = new ArrayList<>();
		try {
			
			states = dao.getListOfState();

			
			states.stream().forEach(state ->{
				System.out.println(state.getState());
			});
//			for (CovidData x : states) {
//				System.out.println(x.getState());
//			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}

	public void getAllDistrictByState(String state) {
		// TODO Auto-generated method stub
		Collection<CovidData> districts = new ArrayList<>();
		try {
			districts = dao.getListofDistrictByState(state);
		       System.out.println("State1 is present "+districts.isEmpty());
			if (districts.isEmpty()) {
				throw new InvalidStateCodeException("Invalid state code. please check your Input");
			} else {
				System.out.println("Districts");
				districts.stream().forEach((district) ->{
					System.out.println(district.getDistrict());
				});
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidStateCodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void getDataBetweenDatesByState(Date startdate, Date enddate) {
		// TODO Auto-generated method stub
		List<CovidData> data = new ArrayList<>();
		CovidData cd = new CovidData();
		try {
			boolean checkStart,checkEnd,finalCheck;
			data = dao.getListofCovidDataByDate(startdate, enddate);
			  checkStart=dao.checkTheDatePresentOrNot(startdate);
			  checkEnd=dao.checkTheDatePresentOrNot(enddate);
		        System.out.println("Start is present "+checkStart);
		        System.out.println("Last is present :"+checkEnd);
		
		      
				if (checkStart) {
					if (checkEnd) {
						if (startdate.compareTo(enddate) < 0) {
							if (data != null) {
								finalCheck = true;
							} else {
								finalCheck = false;
								throw new NoDataFoundException();
							}
						} else {
							finalCheck = false;
							throw new InvalidDateRangeException();
						}
					} else {
						finalCheck = false;
						throw new InvalidDateException("Invalid End date, please check your input");
					}

				} else {
					finalCheck = false;
					throw new InvalidDateException("Invalid Start date, please check your input");
				}

			if (finalCheck) {
				System.out.println("Data between two dates");
				System.out.println("          date|State|Confirmed total|tested|recovered");

				String confirmed, tested;

				for (CovidData x : data) {
					confirmed = String.format("%15.3s", x.getConfirmed());
					tested = String.format("%6s", x.getTested());
					System.out.println(x.getDate() + "    |" + x.getState() + "   |" + confirmed + "|" + tested + "|"
							+ x.getRecovered());
				}
			}
		}

		catch (SQLException | InvalidDateException | InvalidDateRangeException | NoDataFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void compareDataBetweenStateByDate(Date startdate, Date enddate, String state1, String state2) {
		// TODO Auto-generated method stub
		List<CovidData> data = new ArrayList<>();
		Collection<CovidData> district1 = new ArrayList<>();
		Collection<CovidData> district2 = new ArrayList<>();
		try {
			boolean checkStart,checkEnd,finalCheck=false;
			data = dao.getListofConfirmedCovidCaseBetweenTwoState(startdate, enddate, state1, state2);
			district1=dao.getListofDistrictByState(state1);
			district2=dao.getListofDistrictByState(state2);
			  checkStart=dao.checkTheDatePresentOrNot(startdate);
			  checkEnd=dao.checkTheDatePresentOrNot(enddate);
		        System.out.println("Start is present "+checkStart);
		        System.out.println("Last is present :"+checkEnd);
		        System.out.println("State1 is present "+district1.isEmpty());
		        System.out.println("State2 is present :"+district2.isEmpty());
		
		        if(!(district1.isEmpty() && district2.isEmpty())) {
		        	if (checkStart) {
						if (checkEnd) {
							if (startdate.compareTo(enddate) < 0) {
								if (data != null) {
									finalCheck = true;
								} else {
									finalCheck = false;
									throw new NoDataFoundException();
								}
							} else {
								finalCheck = false;
								throw new InvalidDateRangeException();
							}
						} else {
							finalCheck = false;
							throw new InvalidDateException("Invalid End date, please check your input");
						}

					} else {
						finalCheck = false;
						throw new InvalidDateException("Invalid Start date, please check your input");
					}
		        } else {
		        	finalCheck=false;
		        	throw new InvalidStateCodeException("Invalid state code. please check your Input");
		        }
				

			if (finalCheck)
			{
				System.out.println("     date     |First State|Confirmed total|Second State|Confirmed total|");

				String state_1, confirmed1, tested;

		
			for (CovidData y : data) {
					confirmed1 = String.format("%8s", y.getConfirmed());
					tested = String.format("%6s", y.getTested());
					state_1 = String.format("%5s", y.getState());
					System.out.println(y.getDate() + "    |      " + y.getState() + "   |" + confirmed1 + "       |"
							+ tested + "      |" + y.getRecovered());
				}
			}

		} catch (SQLException | InvalidDateException | InvalidDateRangeException | NoDataFoundException | InvalidStateCodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
