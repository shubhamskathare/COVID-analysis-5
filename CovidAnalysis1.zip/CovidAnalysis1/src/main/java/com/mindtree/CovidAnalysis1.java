package com.mindtree;

import java.util.Scanner;

import com.mindtree.controller.CovidDataController;

public class CovidAnalysis1 {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CovidDataController cd = new CovidDataController();
		
//		List<CovidData> data = new ArrayList<>();
		System.out.println("**************************************************");
		System.out.println("1. Get State Name");
		System.out.println("2. Get District name for given states");
		System.out.println("3. Display Date by state with in date range");
		System.out.println("4. Display Confirmed cases by comparing two states for a given date range");
		System.out.println("5. Exit");
		System.out.print("Please select option: ");
		int option = sc.nextInt();
		switch (option) {

		case 1:
			cd.getAllStates();
			break;
		case 2:
			cd.getAllDistrictByState();
			break;
		case 3:
			cd.getDataBetweenDates();
			break;
		case 4:
			cd.compareCovidDataBetweenStates();
			break;
		case 5:
			break;
		}
		

	}

}
