package com.mindtree.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;

import com.mindtree.exception.InvalidDateException;
import com.mindtree.exception.InvalidDateRangeException;
import com.mindtree.exception.InvalidStateCodeException;
import com.mindtree.exception.NoDataFoundException;
import com.mindtree.model.CovidData;

public interface CovidDataDao {
	
	public List<CovidData> getAll() throws SQLException;

	public List<CovidData> getListOfState() throws SQLException;

	public List<CovidData> getListofDistrictByState(String state) throws SQLException, InvalidStateCodeException;

	public List<CovidData> getListofCovidDataByDate(Date startDate, Date endDate)
			throws SQLException, InvalidDateException, InvalidDateRangeException,NoDataFoundException;

	public List<CovidData> getListofConfirmedCovidCaseBetweenTwoState(Date date1, Date date2, String state1,
			String state2)  throws SQLException, InvalidDateException, InvalidDateRangeException,NoDataFoundException;
	
	public boolean checkTheDatePresentOrNot(Date inputDate) throws SQLException;
}
