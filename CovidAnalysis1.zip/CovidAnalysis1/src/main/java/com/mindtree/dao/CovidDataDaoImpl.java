package com.mindtree.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.exception.InvalidDateException;
import com.mindtree.exception.InvalidDateRangeException;
import com.mindtree.exception.InvalidStateCodeException;
import com.mindtree.exception.NoDataFoundException;
import com.mindtree.model.CovidData;

public class CovidDataDaoImpl implements CovidDataDao {
	
	
	String url = "jdbc:mysql://localhost:3306/covid_analysis";
	String uname = "root";
	String pass = "Dsp001@#";
	public static List<CovidData> listofAllData = new ArrayList<>();
	private static final String SELECT_ALL_DATA ="select * from covid_analysis.covid_data";

	private static final String SELECT_ALL_STATE = "Select distinct state from covid_analysis.covid_data order  by state";
	private static final String SELECT_ALL_DISTRICT_BY_STATE = "select distinct district from covid_analysis.covid_data where state=?";
	
	private static final String SELECT_COVID_DATA_BETWEEN_TWO_DATE="select date,state,confirmed,tested,recovered "
			+ "from covid_analysis.covid_data"
			+ " where date between ? and ? group by state ,date; ";
	
	private static final String SELECT_CONFIRMED_CASES_BY_COMPARING_STATES="Select a.date,a.state as state1, a.confirmed as state1_confirmed, b.state as state2, b.confirmed as state2_confirmed\r\n"
			+ "from covid_analysis.covid_data A left join covid_analysis.covid_data B on a.date = b.date \r\n"
			+ "where  a.date between ? and ? and a.state=? and b.state=? group by a.date,a.state;";
	
	private static final String CHECK_THE_DATE_PRESENT_OR_NOT="SELECT * FROM covid_analysis.covid_data where date=?;";
	//get Connection
	  protected Connection getConnection() {
	        Connection connection = null;
	        try {
	        	Class.forName("com.mysql.cj.jdbc.Driver");
	            connection = DriverManager.getConnection(url, uname, pass);
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (ClassNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        return connection;
	    }

	@Override
	public List<CovidData> getListOfState() throws SQLException {
		// TODO Auto-generated method stub
		List<CovidData> listofStates = new ArrayList<>();
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_ALL_STATE);
		
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			CovidData data = new CovidData();
			data.setState(rs.getString("state"));
			listofStates.add(data);
		}
		
//		for(CovidData x:listofStates) {
//			System.out.println(x.getState());
//		}
		return listofStates;
	}

	@Override
	public List<CovidData> getListofDistrictByState(String state) throws SQLException,InvalidStateCodeException {
		// TODO Auto-generated method stub
		List<CovidData> listofDistricts = new ArrayList<>();
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_ALL_DISTRICT_BY_STATE);
		ps.setString(1, state);
		System.out.println(ps);
		ResultSet rs = ps.executeQuery();
		
		while(rs.next() ) 
		{
			CovidData district = new CovidData();
			
			district.setDistrict(rs.getString("district"));
			listofDistricts.add(district);
		}
	
		return listofDistricts;
	}


	@Override
	public List<CovidData> getListofCovidDataByDate(Date startDate, Date endDate)
			throws SQLException, InvalidDateException, InvalidDateRangeException,NoDataFoundException {
		List<CovidData> listofdata = new ArrayList<>();
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_COVID_DATA_BETWEEN_TWO_DATE);
		// TODO Auto-generated method stub
		ps.setDate(1, (java.sql.Date) startDate);
		ps.setDate(2, (java.sql.Date) endDate);
		
		
		ResultSet rs = ps.executeQuery();
		
		while(rs.next() ) 
		{
			CovidData data = new CovidData();
			
			data.setDate(rs.getDate("date"));
			data.setState(rs.getString("state"));
			data.setConfirmed(rs.getString("confirmed"));
			data.setTested(rs.getString("tested"));
			data.setRecovered(rs.getString("recovered"));
		
			listofdata.add(data);
		}
		return listofdata;
	}

	@Override
	public List<CovidData>  getListofConfirmedCovidCaseBetweenTwoState(Date startDate, Date endDate, String state1,
			String state2) throws SQLException, InvalidDateException, InvalidDateRangeException, NoDataFoundException {
		// TODO Auto-generated method stub
		List<CovidData> listofdata = new ArrayList<>();
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_CONFIRMED_CASES_BY_COMPARING_STATES);
		// TODO Auto-generated method stub
		ps.setDate(1, (java.sql.Date) startDate);
		ps.setDate(2, (java.sql.Date) endDate);
		ps.setString(3, state1);
		ps.setString(4, state2);
		
		ResultSet rs = ps.executeQuery();
		while(rs.next() ) 
		{
			CovidData data = new CovidData();
			
			data.setDate(rs.getDate("a.date"));
			data.setState(rs.getString("state1"));
			data.setConfirmed(rs.getString("state1_confirmed"));
			data.setTested(rs.getString("state2"));
			data.setRecovered(rs.getString("state2_confirmed"));
		
			listofdata.add(data);
		}
		return listofdata;
	}

	@Override
	public List<CovidData> getAll() throws SQLException {
		// TODO Auto-generated method stub

		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_ALL_DATA);
		ResultSet rs = ps.executeQuery();
		
		while(rs.next() ) 
		{
			CovidData data = new CovidData();
			
			data.setDate(rs.getDate("date"));
			data.setState(rs.getString("state"));
			data.setDistrict(rs.getString("district"));
			data.setTested(rs.getString("tested"));
			data.setConfirmed(rs.getString("confirmed"));
			data.setRecovered(rs.getString("recovered"));
			data.setId(rs.getInt("id"));
		
			listofAllData.add(data);
		}
		return listofAllData;
	}

	@Override
	public boolean checkTheDatePresentOrNot(Date inputDate) throws SQLException {
		// TODO Auto-generated method stub
		boolean res = false;
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement(CHECK_THE_DATE_PRESENT_OR_NOT);
		ps.setDate(1, inputDate);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			res = true;
		}
		return res;
	}






}
