package com.mindtree.controller;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.mindtree.service.CovidDataService;

public class CovidDataController {
	static Scanner sc = new Scanner(System.in);
	private CovidDataService service ;

//	public void init() {
//		service = new CovidDataService();
//	}

	public CovidDataController() {
		this.service=new CovidDataService();
	}

	public void getAllStates() {
		this.service.getAllState();
	}

	public void getAllDistrictByState() {
		System.out.print("Please enter state code");
		String state = sc.next();
		service.getAllDistrictByState(state);
	}

	public void getDataBetweenDates() {
		// TODO Auto-generated method stub
		System.out.print("Plese enter the start date (yyyy-MM-dd):");
		String startDate = sc.nextLine();
		System.out.print("Plese enter the end date (yyyy-MM-dd):");
		String endDate = sc.nextLine();
		
		Date startdate =  Date.valueOf(startDate);
		Date enddate =  Date.valueOf(endDate);
		new SimpleDateFormat("yyyy-MM-dd").format(startdate);
		new SimpleDateFormat("yyyy-MM-dd").format(enddate);
		service.getDataBetweenDatesByState(startdate, enddate);

	}

	public void compareCovidDataBetweenStates() {
		// TODO Auto-generated method stub

		System.out.print("Plese enter the start date (yyyy-MM-dd):");
		String startDate = sc.nextLine();
		System.out.print("Plese enter the end date (yyyy-MM-dd):");
		String endDate = sc.nextLine();
		System.out.print("Please enter first state code:");
		String state1 = sc.next();
		System.out.print("Please enter second state code:");
		String state2 = sc.next();
		SimpleDateFormat dateInput = new SimpleDateFormat("yyyy-MM-dd");
//		Scanner input = new Scanner(System.in);

		Date startdate =  Date.valueOf(startDate);
		Date enddate =  Date.valueOf(endDate);
		new SimpleDateFormat("yyyy-MM-dd").format(startdate);
		new SimpleDateFormat("yyyy-MM-dd").format(enddate);
		service.compareDataBetweenStateByDate(startdate, enddate, state1, state2);

	}

}

//	Scanner sc = new Scanner(System.in);
//	
//	CovidDataService covidDataService = new CovidDataService();
//	List<CovidData> data= new ArrayList<>();
//		System.out.println("**************************************************");
//		System.out.println("1. Get State Name");
//		System.out.println("2. Get District name for given states");
//		System.out.println("3. Display Date by state with in date range");
//		System.out.println("4. Display Confirmed cases by comparing two states for a given date range");
//		System.out.println("5. Exit");
//		System.out.println("Please select option");
//		int option = sc.nextInt();
//		switch(option) {
//		
//		case 1:
//			covidDataService.getAllState();
//			for(int i=0;i<data.size();i++) {
//				System.out.println(data.get(i));
//			}
//			break;
//		case 2:
//			covidDataService.getAllDistricyByState();
//}
