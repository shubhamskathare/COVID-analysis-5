package com.mindtree.model;

import java.util.Date;

public class CovidData {

	
	private int id;
	private String state;
	private String district;
	private String tested;
	private String confirmed;
	private String recovered;
	private Date date;
	
	public CovidData(int id, String state, String district, String tested, String confirmed, String recovered,
			Date date) {
		super();
		this.id = id;
		this.state = state;
		this.district = district;
		this.tested = tested;
		this.confirmed = confirmed;
		this.recovered = recovered;
		this.date = date;
	}
	
	

	public CovidData() {
		super();
	}



	public CovidData(String state) {
		// TODO Auto-generated constructor stub
		setState(state);
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getTested() {
		return tested;
	}

	public void setTested(String tested) {
		this.tested = tested;
	}

	public String getConfirmed() {
		return confirmed;
	}

	public void setConfirmed(String confirmed) {
		this.confirmed = confirmed;
	}

	public String getRecovered() {
		return recovered;
	}

	public void setRecovered(String recovered) {
		this.recovered = recovered;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}



	@Override
	public String toString() {
		return "Covid_Data [id=" + id + ", state=" + state + ", district=" + district + ", tested=" + tested
				+ ", confirmed=" + confirmed + ", recovered=" + recovered + ", date=" + date + "]";
	}
	
	
	
	
	
}
