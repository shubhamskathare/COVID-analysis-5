package com.mindtree.exception;

public class InvalidDateException extends Exception {

	public InvalidDateException(String string) {
		// TODO Auto-generated constructor stub
		System.out.println(string);
	}

}
