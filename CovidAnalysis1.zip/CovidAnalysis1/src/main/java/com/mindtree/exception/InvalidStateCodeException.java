package com.mindtree.exception;

public class InvalidStateCodeException extends Exception {

	public InvalidStateCodeException(String string) {
		// TODO Auto-generated constructor stub
		System.out.println(string);
	}

	public InvalidStateCodeException() {
		// TODO Auto-generated constructor stub
		System.out.println();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 3491719109282010170L;

}
