package com.mindtree.exception;

public class InvalidDateRangeException extends Exception {
	public InvalidDateRangeException() {
		System.out.println("Invalid Date Range Please check your input");
	}
}
